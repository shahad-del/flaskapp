from setuptools import setup
setup(
    name = 'vsearch',
    version='1.0',
    description = 'learning how to include your module in site package',
    author = 'shahad',
    author_email = 'shahad.sumann@gmail.com',
    url='sitepackages.com',
    py_modules=['vsearch']
)